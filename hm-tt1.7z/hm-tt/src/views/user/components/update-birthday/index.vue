<template>
  <van-datetime-picker
    v-model="currentDate"
    @cancel="$emit('close')"
    @confirm="onConfirm"
    type="date"
    title="选择年月日"
    :min-date="minDate"
    :max-date="maxDate"
  />
</template>

<script>
import dayjs from 'dayjs'
import { updateProfile } from '@/api/user.js'
export default {
  data () {
    return {
      minDate: new Date(1900, 0, 1),
      maxDate: new Date(),
      currentDate: new Date()
    }
  },

  props: {
    value: {
      type: String,
      required: true
    }
  },

  created () {
    this.currentDate = new Date(this.value)
  },

  methods: {
    async onConfirm (value) {
      const formatDate = dayjs(new Date(value)).format('YYYY-MM-DD')
      try {
        await updateProfile({
          birthday: formatDate
        })
        this.$toast('更新成功')
        this.$emit('close')
        this.$emit('input', formatDate)
      } catch (err) {
        this.$toast('更新失败')
      }
    }
  }
}
</script>

<style scoped lang='less'>

</style>
