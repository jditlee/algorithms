<template>
  <div class="artilceList">
    <!-- 文章列表 -->
    <van-pull-refresh
    :success-text="successText"
    :success-duration="1500"
    v-model="isRefreshLoading"
    @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        :error.sync="error"
        error-text="请求失败，点击重新加载"
        @load="onLoad"
      >
        <!-- <van-cell v-for="item in list" :key="item.art_id" :title="item.title" /> -->
        <article-item :article="item" v-for="item in list" :key="item.art_id + ''"></article-item>
      </van-list>
    </van-pull-refresh>
  </div>
</template>

<script>
import { getChannelsArticle } from '@/api/article.js'
import ArticleItem from '@/components/article-item'
export default {
  name: 'articleList',
  props: {
    // key: 是要接受的数据
    // value: 是一个对象
    channel: {
      // 接受的数据类型
      type: Object,
      // 是否必传
      required: true
    }
  },
  components: {
    ArticleItem
  },
  data () {
    return {
      // van-list组件的数据
      list: [],
      // 显示loading效果
      loading: false,
      // 实现加载完成，没有更多数据
      finished: false,
      // 获取数据的时间戳
      timestamp: null,
      // 控制list显示错误
      error: false,
      // 控制下拉loading
      isRefreshLoading: false,
      // 下拉刷新成功文本
      successText: '刷新成功'
    }
  },

  created () {

  },

  methods: {
    async onLoad () {
      // 异步更新数据
      // setTimeout 仅做示例，真实场景中一般为 ajax 请求
      // 1. 发送请求
      try {
        const { data: res } = await getChannelsArticle({
          // 频道id
          channel_id: this.channel.id,
          // 时间戳，如果是获取第一页数据，用当前的时间戳
          timestamp: this.timestamp || Date.now(),
          // 是否包含置顶数据
          with_top: 1
        })
        // 制造错误
        if (Math.random() > 0.5) {
          return console.og('12')
        }
        console.log(res)
        // 2. 得到数据追加给list
        // [{},[]]
        this.list.push(...res.data.results)
        // 3. 本次加载状态结束
        this.loading = false
        // 4. 数据全部加载完成 关闭加载更多数据
        // 只要results.length !=0
        if (res.data.results.length) {
          this.timestamp = res.data.pre_timestamp
        } else {
          this.finished = true
        }
      } catch (err) {
        this.error = true
        this.loading = false
      }
    },
    // 触发下拉
    async onRefresh () {
      try {
        const { data: res } = await getChannelsArticle({
          // 频道id
          channel_id: this.channel.id,
          // 时间戳，如果是获取第一页数据，用当前的时间戳
          timestamp: Date.now(),
          // 是否包含置顶数据
          with_top: 1
        })
        if (Math.random() > 0.5) {
          console.og('1')
        }
        this.list = []
        this.list.unshift(...res.data.results)
        this.isRefreshLoading = false
        this.successText = `亲，刷新成功，加载${res.data.results.length}条数据`
      } catch (err) {
        this.successText = '亲，加载失败'
        this.isRefreshLoading = false
      }
    }
  }
}
</script>

<style scoped lang='less'>
.artilceList {
  height: 80vh;
  overflow-y: scroll;
}
</style>
