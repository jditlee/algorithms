<template>
  <div class="login-box">
    <!-- 顶部导航 -->
    <van-nav-bar
      title="登录"
      class="page-nav-bar"
    >
      <template #left>
        <van-icon @click="$router.go(-1)" name="cross" color="#fff" size="18" />
      </template>
    </van-nav-bar>
    <!-- /顶部导航 -->

    <!-- 登陆表单 -->
    <van-form ref="loginForm" @submit="onSubmit">
      <!-- 手机号 -->
      <van-field
        v-model="user.mobile"
        name="mobile"
        placeholder="请输入手机号码"
        :rules="userFormRules.mobile"
        type="number"
        maxlength="11"
      >
        <i slot="left-icon" class="heimatoutiao hmtt-shouji"></i>
      </van-field>
      <!-- 验证码 -->
      <van-field
        v-model="user.code"
        name="密码"
        placeholder="请输入验证码"
        :rules="userFormRules.code"
        type="number"
        maxlength="6"
      >
        <i slot="left-icon" class="heimatoutiao hmtt-yanzhengma"></i>
        <template #button>
          <van-count-down @finish="isCountDownShow = false" v-if="isCountDownShow" :time="60000" format="ss 秒" />
          <van-button v-else native-type="button" @click="sendCode" class="send-code" round size="small" type="default">发送验证码</van-button>
        </template>
      </van-field>
      <div style="margin: 16px;">
        <van-button class="login-btn" block type="info" native-type="submit">
          登录
        </van-button>
      </div>
    </van-form>
    <!-- /登陆表单 -->
  </div>
</template>

<script>
import { login, sendCode } from '@/api/user.js'
export default {
  name: 'login',
  data () {
    return {
      // 定义所有表单数据对象
      user: {
        mobile: '',
        code: ''
      },
      // 定义校验user表单的规则
      userFormRules: {
        mobile: [
          { required: true, message: '请输入手机号码' },
          { pattern: /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[35678]|18[0-9]|14[57])[0-9]{8}$/, message: '手机号格式不正确' }
        ],
        code: [
          { required: true, message: '请输入验证码' },
          { pattern: /^\d{6}/, message: '验证码格式不正确' }
        ]
      },
      // 控制倒计时显示/隐藏
      isCountDownShow: false
    }
  },

  created () {

  },

  methods: {
    // 点击提交
    async onSubmit () {
      // 点击 登录触发
      // 1. 获取到输入框的值
      // 2. 校验
      // 3. 发送请求 await修饰promise
      // loading加载
      this.$toast.loading({
        duration: 0, // 持续展示 toast
        message: '登录中...', // 提示文字
        forbidClick: true // 透明的遮罩
      })
      try {
        const { data: res } = await login(this.user)
        // 调用mutations里的changeUser方法
        this.$store.commit('changeUser', res.data)
        this.$toast.success('登录成功')
        this.$router.go(-1)
      } catch (err) {
        console.dir(err)
        // 如果err错误信息里的响应状态码为400代表手机或者验证码错误
        if (err.response.status === 400) return this.$toast.fail('手机或者验证码错误')
        this.$toast.fail('网络错误，请稍后重试')
      }
    },
    // 点击发送验证码
    async sendCode () {
      try {
        await this.$refs.loginForm.validate('mobile')
      } catch (err) {
        // 一旦进入err
        return false
      }

      this.isCountDownShow = true
      // 发送请求
      try {
        await sendCode(this.user.mobile)
        this.$toast.success('发送成功')
      } catch (err) {
        this.isCountDownShow = false
        // 如果状态码等于429，1分钟内重复发送
        if (err.response.status === 429) {
          return this.$toast.fail('亲，发送频繁')
        }
        this.$toast.fail('亲，发送失败')
      }
    }
  }
}
</script>

<style scoped lang='less'>
.login-box {
  .heimatoutiao {
    font-size: 37px;
  }

  // 发送验证码
  .send-code {
    width: 162px;
    height: 46px;
    background: #EDEDED;
    color: #666;
  }

  .login-btn {
    margin: 53px 0;
    background: #6DB4FB;
    border: none;
  }
}
</style>
