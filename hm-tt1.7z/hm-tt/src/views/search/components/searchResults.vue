<template>
  <div class="results">
    <van-list
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      :error.sync="error"
      error-text="请求失败，点击重新加载"
      @load="onLoad"
    >
      <van-cell v-for="item in list" :key="item.art_id" :title="item.title" />
    </van-list>
  </div>
</template>

<script>
import { getSearchResults } from '@/api/search.js'
export default {
  data () {
    return {
      list: [],
      loading: false,
      finished: false,
      // 搜索结果的页码
      page: 1,
      // 每页条数
      per_page: 10,
      // 显示错误信息
      error: false
    }
  },

  props: {
    searchText: {
      type: String,
      required: true
    }
  },

  created () {

  },

  methods: {
    async onLoad () {
      // 1. 异步获取数据
      try {
        const { data: res } = await getSearchResults({
          page: this.page,
          per_page: this.per_page,
          q: this.searchText
        })
        if (Math.random() > 0.5) return console.og('23')
        // 2. 将数据保存
        this.list.push(...res.data.results)
        // 3. 本次加载状态结束
        this.loading = false
        // 4. 数据全部加载完成
        // 现在先这样写：res.data.results.length
        // 这也不准：res.data.results.length < this.per_page
        // 当前的页码 （5） * 每页的条数（10） > 总条数
        if (res.data.results.length) {
          this.page++
        } else {
          this.finished = true
        }
      } catch (err) {
        // 显示错误提示
        this.error = true
        // 停止本次加载
        this.loading = false
      }
    }
  }
}
</script>

<style scoped lang='less'>

</style>
