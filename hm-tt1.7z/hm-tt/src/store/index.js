import Vue from 'vue'
import Vuex from 'vuex'
import { getItem, setItem } from '@/utils/storage.js'

Vue.use(Vuex)

const HMTT_TOKEN = 'HMTT_TOKEN'
export default new Vuex.Store({
  state: {
    // 用来存储token和refreshtoken
    user: getItem(HMTT_TOKEN)
  },
  mutations: {
    // 给user同步数据
    changeUser (state, data) {
      state.user = data
      setItem(HMTT_TOKEN, data)
    }
  },
  actions: {
  },
  modules: {
  }
})
