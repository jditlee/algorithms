/**
 * 封装本地存储的方法
 */

/**
 * 保存数据
 * @param {*} key 保存本地数据的key
 * @param {*} value 保存本地数据的值
 */
export const setItem = (key, value) => {
  if (typeof value === 'object') {
    value = JSON.stringify(value)
  }
  window.localStorage.setItem(key, value)
}

/**
 * 获取数据
 * @param {*} key 获取本地数据的key
 */
export const getItem = key => {
  const data = window.localStorage.getItem(key)
  try {
    // 如果 data是json字符串，调用JSON.parse(data)会得到一个对象
    // 如果 data 是一个普通字符串，调用JSON.parse(data)会报错
    return JSON.parse(data)
  } catch (err) {
    // data 是普通字符串
    return data
  }
}

/**
 * 移除数据
 * @param {*} key 移除本地数据的key
 */
export const removeItem = key => {
  window.localStorage.removeItem(key)
}
