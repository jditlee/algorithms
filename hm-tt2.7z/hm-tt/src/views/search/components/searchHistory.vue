<template>
  <div class="history">
    <van-cell title="搜索历史">
      <div class="history_right">
        <div v-if="isShowDel">
          <!-- <span @click="$emit('clear-history')">全部删除</span> -->
          <span @click="history.splice(0)">全部删除</span>
          <span @click="isShowDel = false" style="margin-left: 8px;">完成</span>
        </div>
        <van-icon @click="isShowDel = true" v-else name="delete" />
      </div>
    </van-cell>
    <van-cell
    v-for="(item, index) in history"
    :key="item"
    @click="clickHistory(index, item)"
    :title="item">
      <van-icon v-if="isShowDel" name="close" />
    </van-cell>
    <van-empty v-if="!history.length" image="error" description="暂无搜索历史" />
  </div>
</template>

<script>
export default {
  data () {
    return {
      isShowDel: false
    }
  },

  props: {
    history: {
      type: Array,
      required: true
    }
  },

  created () {

  },

  methods: {
    clickHistory (index, searchVal) {
      if (this.isShowDel) {
        // 删除
        // 父组件传递给子组建的数据，如果是值类型，不能修改
        // 如果是复杂数据类型，也不能直接修改 this.history = []
        //     但是可以对history的内部数据内进行修改
        this.history.splice(index, 1)
      } else {
        // 搜索
        this.$emit('search', searchVal)
      }
    }
  }
}
</script>

<style scoped lang='less'>

</style>
