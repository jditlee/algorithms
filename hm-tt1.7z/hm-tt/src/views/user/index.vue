<template>
  <div>
    <van-nav-bar
      title="个人中心"
      class="page-nav-bar"
      left-arrow
      @click-left="$router.go(-1)"
    />
    <input type="file" @change="onFileChange" ref="file" hidden>
    <van-cell title="头像" @click="$refs.file.click()" is-link value="内容">
      <van-image
        round
        class="avatar"
        :src="userInfo.photo"
      />
    </van-cell>
    <van-cell
    title="昵称"
    @click="isShowEditNickName = true"
    is-link
    :value="userInfo.name" />
    <van-cell title="性别" @click="isShowEditSex = true" is-link :value="!userInfo.gender ? '男' : '女'" />
    <van-cell title="生日" @click="isShowEditBirthday = true" is-link :value="userInfo.birthday" />

    <!-- 编辑昵称的弹层 -->
    <van-popup v-model="isShowEditNickName" position="bottom" :style="{ height: '100%' }">
      <!-- :value="userInfo.name" @input="userInfo.name = $event" -->
      <updateName v-if="isShowEditNickName" v-model="userInfo.name" @click-left="isShowEditNickName = false" />
    </van-popup>

    <!-- 编辑性别的弹层 -->
    <van-popup v-model="isShowEditSex" position="bottom">
      <!-- :value="userInfo.gender" @input="userInfo.gender = $event" -->
      <updateSex v-if="isShowEditSex" @close="isShowEditSex = false" v-model="userInfo.gender" />
    </van-popup>

    <!-- 编辑生日的弹层 -->
    <van-popup v-model="isShowEditBirthday" position="bottom">
      <!-- :value="userInfo.birthday" @input="userInfo.birthday = $event" -->
      <updateBirthday v-if="isShowEditBirthday" @close="isShowEditBirthday = false" v-model="userInfo.birthday"/>
    </van-popup>

    <!-- 编辑头像的弹层 -->
    <van-popup v-model="isShowEditAvatar" position="bottom" style="height: 100%">
      <updateAvatar v-if="isShowEditAvatar" @on-success="userInfo.photo = $event" @cancel="isShowEditAvatar = false" :imgUrl="imgUrl" />
    </van-popup>
  </div>
</template>

<script>
import { getUserProfile } from '@/api/user.js'
import updateName from './components/update-name'
import updateSex from './components/update-sex'
import updateBirthday from './components/update-birthday'
import updateAvatar from './components/update-avatr'
export default {
  name: 'user',
  data () {
    return {
      userInfo: {},
      isShowEditNickName: false,
      isShowEditSex: false,
      isShowEditBirthday: false,
      isShowEditAvatar: false,
      imgUrl: ''
    }
  },

  components: {
    updateName,
    updateSex,
    updateBirthday,
    updateAvatar
  },

  created () {
    this.loadGetUser()
  },

  methods: {
    async loadGetUser () {
      try {
        const { data: { data } } = await getUserProfile()
        this.userInfo = data
      } catch (err) {
        this.$toast.fail('获取用户信息失败')
      }
    },
    // 点击选择图片打开
    onFileChange () {
      // 获取上传图片
      const file = this.$refs.file.files[0]
      const url = window.URL.createObjectURL(file)
      this.imgUrl = url
      this.isShowEditAvatar = true
      // 防止两次的value值相同不触发change
      this.$refs.value = ''
    }
  }
}
</script>

<style scoped lang='less'>
/deep/.page-nav-bar {
  .van-icon-arrow-left {
    color: #fff;
  }
}

.avatar {
  width: 58px;
  height: 58px;
}
</style>
