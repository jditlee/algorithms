/**
 * 关于评论请求模块
 */

import request from '../utils/request.js'
/**
 * 获取评论
 */
export const getCommentList = params => {
  return request({
    url: '/app/v1_0/comments',
    method: 'GET',
    params
  })
}

/**
 * 对评论进行点赞
 * @param {*} target 评论的id
 */
export const addCommentLike = target => {
  return request({
    url: '/app/v1_0/comment/likings',
    method: 'POST',
    data: {
      target
    }
  })
}

/**
 * 对评论取消点赞
 * @param {*} target 评论的id
 */
export const deleteCommentLike = target => {
  return request({
    url: '/app/v1_0/comment/likings/' + target,
    method: 'DELETE'
  })
}

/**
 * 发布评论
 * @param {*} data 发布评论参数对象
 */
export const postComment = data => {
  return request({
    url: '/app/v1_0/comments',
    method: 'POST',
    data
  })
}
