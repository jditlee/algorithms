//  关于文章请求的接口
import request from '../utils/request.js'
/**
 * 获取频道新闻列表 频道新闻推荐_V1.1
 */
export const getChannelsArticle = params => {
  return request({
    url: '/app/v1_1/articles',
    method: 'GET',
    params
  })
}

/**
 * 通过文章id获取详情数据
 * @param {*} articleId 文章id
 */
export const getArticleById = articleId => {
  return request({
    url: '/app/v1_0/articles/' + articleId,
    method: 'GET'
  })
}

/**
 * 添加收藏
 * @param {*} target 收藏的目标文章id
 */
export const addCollect = target => {
  return request({
    url: '/app/v1_0/article/collections',
    method: 'POST',
    data: {
      target
    }
  })
}

/**
 * 取消收藏
 * @param {*} target 取消收藏的文章id
 */
export const deleteCollect = target => {
  return request({
    url: '/app/v1_0/article/collections/' + target,
    method: 'DELETE'
  })
}
