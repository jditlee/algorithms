<template>
  <van-list
    v-model="loading"
    :finished="finished"
    finished-text="没有更多了"
    :error.sync="error"
    error-text="请求失败，点击重新加载"
    @load="onLoad"
  >
    <commentItem @click-reply="$emit('click-reply', $event)" v-for="item in list" :key="item.com_id + ''" :comment="item"></commentItem>
  </van-list>
</template>

<script>
import { getCommentList } from '@/api/comment.js'
import commentItem from '../comment-item'
export default {
  data () {
    return {
      loading: false,
      finished: false,
      // 获取评论下一页的标识
      offset: null,
      error: false
    }
  },

  components: {
    commentItem
  },

  props: {
    // 可能是文章id 评论id
    source: {
      type: [Number, String, Object],
      required: true
    },
    // 接收父组件传递过来的list
    list: {
      type: Array,
      required: true
    },
    type: {
      type: String,
      default: 'a'
    }
  },

  created () {},
  methods: {
    async onLoad () {
      // 01. 异步更新数据
      try {
        const { data: res } = await getCommentList({
          type: this.type, // a: 获取文章的评论 c: 评论的评论
          source: this.source + '',
          offset: this.offset,
          limit: 10
        })
        if (Math.random() > 0.5) return console.og('123')
        // 02. 将返回的胡数据保存
        this.list.push(...res.data.results)
        // 03. 本次加载状态结束
        this.loading = false
        this.offset = res.data.last_id
        this.$emit('update-count', res.data.total_count)
        // 04. 数据全部加载完成
        if (this.list.length >= res.data.total_count) {
          this.finished = true
        }
      } catch (err) {
        this.$toast.fail('获取数据失败')
        this.error = true
        this.loading = false
      }
    }
  }
}
</script>

<style scoped lang='less'>

</style>
