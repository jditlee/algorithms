<template>
  <div class="channel_edit">
    <!-- 我的频道 -->
    <van-cell :border="false" title="我的频道">
      <van-button @click="isShowEdit = !isShowEdit" class="edit_btn" plain round size="small" type="danger">{{
       isShowEdit ? '完成' : '编辑' }}</van-button>
    </van-cell>
    <!-- 我的频道列表 -->
    <van-grid class="my_channel" :gutter="10">
      <van-grid-item
      @click="onMyChannel(index)"
      v-for="(channel, index) in myChannels"
      class="channel_item"
      :class="index === active ? 'active' : ''"
      :key="channel.id"
      :text="channel.name">
        <van-icon v-show="isShowEdit && index!==0" slot="icon" name="close" />
      </van-grid-item>
    </van-grid>
    <!-- 频道推荐 -->
    <van-cell :border="false" title="频道推荐"></van-cell>
    <van-grid class="recommend_channel" :gutter="10">
      <van-grid-item @click="onAddChannels(item)" icon="plus" class="channel_item" v-for="item in recommendChannels" :key="item.id" :text="item.name" />
    </van-grid>
  </div>
</template>

<script>
import { getAllChannels, addUserChannels, deleteUserChannels } from '@/api/channels.js'
import { mapState } from 'vuex'
import { setItem } from '@/utils/storage.js'
export default {
  data () {
    return {
      allChannels: [],
      isShowEdit: false
    }
  },

  props: {
    // 接收父组件传递过来的我的频道列表
    myChannels: {
      type: Array,
      required: true
    },
    // 接收选中高亮的索引
    active: {
      type: Number,
      required: true
    }
  },

  computed: {
    // 获取vuex中的user
    ...mapState(['user']),
    recommendChannels () {
      // 直接返回filter过滤之后的数组
      return this.allChannels.filter(item => {
        // this.myChannels.find: 两个值
        // 如果通过find找到了这一项，返回值：就是找到的这一项
        // 如果通过find没有找到这一项 返回值: undefined
        return !this.myChannels.find(mychannel => mychannel.id === item.id)
      })
    }
  },

  created () {
    this.loadGetChannels()
  },

  methods: {
    // 加载所有频道列表数据
    async loadGetChannels () {
      try {
        const { data: res } = await getAllChannels()
        this.allChannels = res.data.channels
      } catch (err) {
        this.$toast.fail('获取失败')
      }
    },
    // 点击推荐频道进行添加
    onAddChannels (item) {
      this.myChannels.push(item)
      // 数据持久化
      if (this.user) {
        // 1. 已登录：存到数据库
        try {
          addUserChannels({
            id: item.id,
            seq: this.myChannels.length
          })
        } catch (err) {
          this.$toast.fail('添加失败')
        }
      } else {
        // 2. 未登录：存到本地
        setItem('hmtt_channels', this.myChannels)
      }
    },
    // 点击我的频道
    onMyChannel (index) {
      if (this.isShowEdit) {
        if (index === 0) return
        if (index <= this.active) {
          this.$emit('updateActive', this.active - 1, true)
        }
        // 删除
        const id = this.myChannels[index].id
        this.myChannels.splice(index, 1)
        // 持久化
        this.deleteChannels(id)
      } else {
        // 切换
        // 子相父传值，通过$emit
        // 1. 自定义事件 (定义在当前组件的标签上)
        // 2. 传递的数据
        this.$emit('updateActive', index)
      }
    },
    // 删除数据持久化
    deleteChannels (id) {
      if (this.user) {
        // 已登录
        try {
          deleteUserChannels(id)
        } catch (err) {
          this.$toast.fail('删除失败')
        }
      } else {
        setItem('hmtt_channels', this.myChannels)
      }
    }
  }
}
</script>

<style scoped lang='less'>
.channel_edit {
  padding-top: 80px;
  .edit_btn {
    width: 104px;
    height: 48px;
    border-radius: 30px;
    color: #f85959;
  }

  /deep/.channel_item {
    .van-grid-item__content {
      background-color: #F3F5F5;
      width: 160px;
      height: 86px;
      border-radius: 6px;
      padding: 0;
      .van-grid-item__text {
        font-size: 28px;
        color: #212121;
      }
    }
    .van-grid-item__content::after {
      border-width: 0;
      border: none;
    }
  }

  /deep/.active {
    .van-grid-item__text {
      color: red !important;
    }
  }

  /deep/.my_channel {
    .van-grid-item__icon-wrapper {
      position: unset;
    }
    .van-icon-close {
      position: absolute;
      font-size: 36px;
      top: -13px;
      right: -13px;
    }
    .van-grid-item__text {
      margin-top: 0px;
    }
  }

  // 频道推荐 + 和 文本样式处理
  /deep/.recommend_channel {
    .van-grid-item__content {
      flex-direction: row;
      .van-icon-plus {
        font-size: 24px;
        color: #333;
      }
      .van-grid-item__text {
        margin-left: 5px;
        margin-top: 8px;
      }
    }
  }
}
</style>
