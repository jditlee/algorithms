import Vue from 'vue'
// 引入dayjs
import dayjs from 'dayjs'
// 引入中文语言包
import 'dayjs/locale/zh-cn'
// 引入relativeTime插件
import relativeTime from 'dayjs/plugin/relativeTime'
// 使用语言包
dayjs.locale('zh-cn') // 全局使用
dayjs.extend(relativeTime)

// 定义全局过滤器配合dayjs实现时间的过滤
// 过滤器函数第一个形参永远都是 dateFormat要过滤的数据
Vue.filter('dateFormat', (data) => {
  return dayjs().to(dayjs(data))
})
