<template>
  <div class="home_container" ref="home">
    <!-- 搜索导航栏 -->
    <van-nav-bar
      class="page-nav-bar"
      fixed
    >
      <van-button to="/search" icon="search" class="search_btn" slot="title" round type="info">搜索</van-button>
    </van-nav-bar>

    <!-- tabs标签页 -->
    <van-tabs class="home-tabs" v-model="active" animated swipeable>
      <van-tab :key="item.id" v-for="item in channels" :title="item.name">
        <!-- 使用组件 -->
        <article-list :channel="item"></article-list>
      </van-tab>
      <div class="placeholder_box" slot="nav-right">
      </div>
      <!-- 汉堡按钮 -->
      <div @click="isShowEditPopup = true" class="hamburger_btn" slot="nav-right">
        <i class="heimatoutiao hmtt-gengduo"></i>
      </div>
    </van-tabs>
    <!-- 编辑频道弹层 -->
    <van-popup
      v-model="isShowEditPopup"
      closeable
      close-icon-position="top-left"
      position="bottom"
      :style="{ height: '90%' }"
    >
      <ChannelEdit @updateActive="onUpdateActive" :my-channels="channels" :active="active" />
    </van-popup>
  </div>
</template>

<script>
import { getChannels } from '@/api/user.js'
// 导入文章列表组件
import ArticleList from './components/articleList.vue'
// 导入频道编辑组件
import ChannelEdit from './components/channelEdit.vue'
import { mapState } from 'vuex'
import { getItem } from '@/utils/storage.js'
export default {
  name: 'home',
  data () {
    return {
      active: 0,
      // 所有的频道列表
      channels: [],
      // 控制弹层显示/隐藏
      isShowEditPopup: false
    }
  },

  components: {
    // 注册组件
    ArticleList,
    ChannelEdit
  },

  created () {
    this.loadChannels()
  },

  computed: {
    ...mapState(['user'])
  },

  methods: {
    // 加载首页用户的频道列表
    async loadChannels () {
      try {
        // 如果用户登录 发送请求获取回来
        // 如果用户未登录
        //   但是本地没有存储数据 发送请求获取回来
        //   本地有数据  获取本地的数据
        // 如果用户未登录并且本地还有数据 获取本地数据
        const localChannels = getItem('hmtt_channels')
        if (!this.user && localChannels) {
          this.channels = localChannels
          return false
        }
        const { data: res } = await getChannels()
        this.channels = res.data.channels
      } catch (err) {
        this.$toast.fail('获取频道列表数据失败')
      }
    },
    onUpdateActive (index, flag = false) {
      this.active = index
      this.isShowEditPopup = flag
    }
  }
}
</script>

<style scoped lang='less'>
.home_container {
  padding-bottom: 100px;
  // 凡是遇到组件内部的类名样式修改不起作用,在前面加上/deep/
  /deep/.van-nav-bar {
    .van-nav-bar__title {
      max-width: unset;
    }
  }
  .search_btn {
    width: 555px;
    height: 64px;
    background: rgba(255, 255, 255, .2);
    border-radius: 32px;
  }
  .van-nav-bar .van-icon {
    color: #fff;
  }

  // 标签页的样式覆盖
  /deep/.home-tabs {
    padding-top: 172px;
    .van-tabs__wrap {
      position: fixed;
      top: 92px;
      z-index: 2;
      width: 100%;
    }
    .van-tabs__nav {
      padding-bottom: 0;
      height: 80px;
    }
    .van-tab {
      min-width: 190px;
      border-right: 1px solid #eee;
    }

    .van-tabs__line {
      width: 31px;
      height: 6px;
      background: #3295F9;
      border-radius: 3px;
      bottom: 8px;
    }

    .placeholder_box {
      width: 66px;
      height: 82px;
      flex-shrink: 0;
    }

    // 汉堡菜单
    .hamburger_btn {
      width: 66px;
      height: 82px;
      background: #fff;
      position: fixed;
      right: 0;
      text-align: center;
      line-height: 82px;
      opacity: 0.9;
      .hmtt-gengduo {
        font-size: 40px;
      }
      &:before {
        content: '';
        width: 2px;
        height: 100%;
        background: url(~@/assets/gradient-gray-line.png);
        position: absolute;
        left: 0;
        top: 0;
        background-size: contain;
      }
    }
  }
}
</style>
