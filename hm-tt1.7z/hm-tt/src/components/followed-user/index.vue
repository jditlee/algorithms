<template>
  <van-button
    v-if="!isFollowed"
    class="follow-btn"
    type="info"
    color="#3296fa"
    round
    :loading="isFollowedLoading"
    size="small"
    icon="plus"
    @click="clickFollowed"
  >关注</van-button>
  <van-button
    v-else
    class="follow-btn"
    round
    size="small"
    :loading="isFollowedLoading"
    @click="clickFollowed"
  >已关注</van-button>
</template>

<script>
import { followedUser, cancelFollowedUser } from '@/api/user.js'
export default {
  data () {
    return {
      // 控制关注loading
      isFollowedLoading: false
    }
  },

  // 修改v-model默认传递的属性和默认定义的时间名字
  model: {
    // 修改默认的属性 （value）
    prop: 'isFollowed',
    // 修改默认的事件名字（input）
    event: 'update-follow'
  },

  props: {
    isFollowed: {
      type: Boolean,
      required: true
    },
    autId: {
      type: [Number, Object],
      required: true
    }
  },

  created () {

  },

  methods: {
    // 点击关注 或 取消关注
    async clickFollowed () {
      this.isFollowedLoading = true
      try {
        if (this.isFollowed) {
          // 关注用户 操作 取消关注
          await cancelFollowedUser(this.autId)
        } else {
          // 未关注 操作 关注
          await followedUser(this.autId)
        }
      } catch (err) {
        if (err.response && err.response.status === 400) {
          return this.$toast.fail('亲，不能关注自己呦')
        }
        this.$toast.fail('操作失败')
      }
      this.isFollowedLoading = false
      // 不能在组建直接修改父组件传递过来值类型数据
      // this.is_followed = !this.is_followed
      this.$emit('update-follow', !this.isFollowed)
    }
  }
}
</script>

<style scoped lang='less'>

</style>
