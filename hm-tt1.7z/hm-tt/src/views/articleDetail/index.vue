<template>
  <div class="article-container">
    <!-- 导航栏 -->
    <van-nav-bar
      class="page-nav-bar"
      left-arrow
      title="黑马头条"
    ></van-nav-bar>
    <!-- /导航栏 -->

    <div class="main-wrap">
      <!-- 加载中 -->
      <div v-if="isLoading" class="loading-wrap">
        <van-loading
          color="#3296fa"
          vertical
        >加载中</van-loading>
      </div>
      <!-- /加载中 -->

      <!-- 加载完成-文章详情 -->
      <div v-else-if="article.title" class="article-detail">
        <!-- 文章标题 -->
        <h1 class="article-title">{{ article.title }}</h1>
        <!-- /文章标题 -->

        <!-- 用户信息 -->
        <van-cell class="user-info" center :border="false">
          <van-image
            class="avatar"
            slot="icon"
            round
            fit="cover"
            :src="article.aut_photo"
          />
          <div slot="title" class="user-name">{{ article.aut_name }}</div>
          <div slot="label" class="publish-date">{{ article.pubdate | dateFormat }}</div>
          <!-- 1. 抽离组件结构 -->
          <!-- 2. 引入注册组件、使用组件 -->
          <!-- 3. 看报错，将数据传递给子组件 -->
          <!-- 4. 依次看报错缺少什么 -->
          <!-- <followUser
          @update-follow="article.is_followed = $event"
          :autId="article.aut_id"
          :isFollowed="article.is_followed" /> -->
          <!-- v-model="article.is_followed" -->
          <!-- 1. <followUser :value="article.is_followed" /> -->
          <!-- 2. <followUser @input="article.is_followed = $event" /> -->
          <followUser
          :autId="article.aut_id"
          v-model="article.is_followed" />
        </van-cell>
        <!-- /用户信息 -->

        <!-- 文章内容 -->
        <div ref="content" class="markdown-body article-content" v-html="article.content"></div>
        <van-divider>正文结束</van-divider>

        <!-- 评论组件 -->
        <commentList :list="list" @click-reply="onClickReply" @update-count="totalCount = $event" :source="article.art_id" />

        <!-- 底部区域 -->
        <div class="article-bottom">
          <van-button
            class="comment-btn"
            type="default"
            round
            size="small"
            @click="isPostCommentShow = true"
          >写评论</van-button>
          <van-icon
            name="comment-o"
            :info="totalCount"
            color="#777"
          />
          <!-- <articleCollect :value="article.is_collected" @input="article.is_collected = $event" /> -->
          <articleCollect :artId="article.art_id" v-model="article.is_collected" />
          <van-icon
            color="#777"
            name="good-job-o"
          />
          <van-icon name="share" color="#777777"></van-icon>
        </div>
        <!-- /底部区域 -->
      </div>
      <!-- /加载完成-文章详情 -->

      <!-- 加载失败：404 -->
      <div v-else-if="errStatus === 404" class="error-wrap">
        <van-icon name="failure" />
        <p class="text">该资源不存在或已删除！</p>
      </div>
      <!-- /加载失败：404 -->

      <!-- 加载失败：其它未知错误（例如网络原因或服务端异常） -->
      <div v-else class="error-wrap">
        <van-icon name="failure" />
        <p class="text">内容加载失败！</p>
        <van-button @click="loadArticle" class="retry-btn">点击重试</van-button>
      </div>
      <!-- /加载失败：其它未知错误（例如网络原因或服务端异常） -->
    </div>

    <!-- 评论弹层 -->
    <van-popup v-model="isPostCommentShow" position="bottom">
      <commentPost @on-success="onSuccess" :target="article.art_id" />
    </van-popup>

    <!-- 回复评论弹层 -->
    <van-popup
    v-model="isPostReplyCommentShow"
    style="height: 100%"
    position="bottom">
      <commentReply v-if="isPostReplyCommentShow" :comment="comment" @click-left="isPostReplyCommentShow = false" />
    </van-popup>
  </div>
</template>

<script>
import { getArticleById } from '@/api/article.js'
import { ImagePreview } from 'vant'
import followUser from '@/components/followed-user'
import articleCollect from '@/components/article-collect'
import commentList from './components/comment-list'
import commentPost from './components/comment-post'
import commentReply from './components/comment-reply'
export default {
  name: 'articleDetail',
  data () {
    return {
      article: {},
      // 控制是否显示加载中
      isLoading: true,
      // 判断是否为资源不存在的错误
      errStatus: 0,
      // 评论总数
      totalCount: 0,
      isPostCommentShow: false,
      // 将评论列表子组件的list提升到父组件
      list: [],
      // 控制回复评论弹层
      isPostReplyCommentShow: false,
      comment: {}
    }
  },

  provide () {
    return {
      artId: this.articleId
    }
  },

  // watch: {
  //   article: {
  //     handler () {
  //       // 等数据发生变化并且页面渲染完成
  //       this.$nextTick(() => this.previewImg())
  //     },
  //     deep: true
  //   }
  // },

  props: {
    articleId: {
      type: [Number, String],
      required: true
    }
  },

  components: {
    // 关注用户
    followUser,
    // 收藏文章
    articleCollect,
    // 评论列表
    commentList,
    // 发布评论
    commentPost,
    // 回复评论
    commentReply
  },
  created () {
    this.loadArticle()
  },

  methods: {
    // 加载文章详情
    async loadArticle () {
      try {
        const { data: { data: article } } = await getArticleById(this.articleId)
        // if (Math.random() > 0.5) return console.og('12')
        this.article = article
      } catch (err) {
        console.dir(err)
        if (err.response && err.response.status === 404) {
          this.errStatus = 404
        }
        this.$toast.fail('获取数据失败')
      }
      // 关闭加载loading
      this.isLoading = false
      this.$nextTick(() => this.previewImg())
    },
    // 预览图片
    previewImg () {
      const content = this.$refs.content
      if (!content) return
      const imgs = content.querySelectorAll('img')
      // 所有预览图片的集合
      const images = []
      imgs.forEach((element, index) => {
        images.push(element.src)
        element.onclick = () => {
          ImagePreview({
            // 所有的图片集合
            images,
            // 预览的起始位置，从0开始
            startPosition: index
          })
        }
      })
    },
    // 监听发布成功
    onSuccess (obj) {
      this.list.unshift(obj)
      this.isPostCommentShow = false
    },
    // 子组件的子组件的评论项点击回复
    onClickReply (comment) {
      this.comment = comment
      this.isPostReplyCommentShow = true
    }
  }
}
</script>

<style scoped lang="less">
@import "./github-markdown.css";
.article-container {
  .main-wrap {
    position: fixed;
    left: 0;
    right: 0;
    top: 92px;
    bottom: 88px;
    overflow-y: scroll;
    background-color: #fff;
  }
  .article-detail {
    .article-title {
      font-size: 40px;
      padding: 50px 32px;
      margin: 0;
      color: #3a3a3a;
    }

    .user-info {
      padding: 0 32px;
      .avatar {
        width: 70px;
        height: 70px;
        margin-right: 17px;
      }
      .van-cell__label {
        margin-top: 0;
      }
      .user-name {
        font-size: 24px;
        color: #3a3a3a;
      }
      .publish-date {
        font-size: 23px;
        color: #b7b7b7;
      }
      .follow-btn {
        width: 170px;
        height: 58px;
      }
    }

    .article-content {
      padding: 55px 32px;
      /deep/ p {
        text-align: justify;
      }
    }
  }

  .loading-wrap {
    padding: 200px 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #fff;
  }

  .error-wrap {
    padding: 200px 32px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #fff;
    .van-icon {
      font-size: 122px;
      color: #b4b4b4;
    }
    .text {
      font-size: 30px;
      color: #666666;
      margin: 33px 0 46px;
    }
    .retry-btn {
      width: 280px;
      height: 70px;
      line-height: 70px;
      border: 1px solid #c3c3c3;
      font-size: 30px;
      color: #666666;
    }
  }

  .article-bottom {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: space-around;
    align-items: center;
    box-sizing: border-box;
    height: 88px;
    border-top: 1px solid #d8d8d8;
    background-color: #fff;
    .comment-btn {
      width: 282px;
      height: 46px;
      border: 2px solid #eeeeee;
      font-size: 30px;
      line-height: 46px;
      color: #a7a7a7;
    }
    .van-icon {
      font-size: 40px;
      .van-info {
        font-size: 16px;
        background-color: #e22829;
      }
    }
  }
}
</style>
