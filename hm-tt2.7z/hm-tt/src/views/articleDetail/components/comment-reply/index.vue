<template>
  <div>
    <van-nav-bar
      :title="!comment.reply_count ? '暂无回复' : comment.reply_count + '条回复'"
      @click-left="$emit('click-left')"
    >
      <van-icon slot="left" name="cross" />
    </van-nav-bar>
    <!-- 使用评论项组件 -->
    <div class="scroll-warp">
      <commentItem :comment="comment"/>
      <van-cell title="全部回复" />
      <commentList :source="comment.com_id" :list="list" type="c"/>
    </div>

    <!-- 底部评论区域 -->
    <div class="post-warp">
      <van-button @click="isShowPostReply = true" round>评论</van-button>
    </div>

    <!-- 发布评论弹层 -->
    <van-popup v-model="isShowPostReply" position="bottom">
      <!--
        event
        on-success:事件用来监听发布成功,并且事件函数的形参可以或获取到发布成功的评论数据
        prop
        target
      -->
      <commentPost @on-success="onSuccess" :target="comment.com_id" />
    </van-popup>
  </div>
</template>

<script>
import commentItem from '../comment-item'
import commentList from '../comment-list'
import commentPost from '../comment-post'
export default {
  data () {
    return {
      list: [],
      isShowPostReply: false
    }
  },

  components: {
    commentItem,
    commentList,
    commentPost
  },

  props: {
    comment: {
      type: Object,
      required: true
    }
  },

  created () {

  },

  methods: {
    onSuccess (res) {
      this.list.unshift(res)
      this.isShowPostReply = false
    }
  }
}
</script>

<style scoped lang='less'>
.post-warp {
  width: 100%;
  height: 100px;
  position: fixed;
  bottom: 0;
  border-top: 1px solid #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
  .van-button {
    width: 640px;
    height: 80px;
  }
}

.scroll-warp {
  position: absolute;
  width: 100%;
  top: 92px;
  bottom: 100px;
  overflow-y: scroll;
}
</style>
