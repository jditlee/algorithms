<template>
  <van-cell-group class="article_item">
    <van-cell :to="'/article/detail/' + article.art_id">
    <!-- <van-cell :to="{name: 'articleDetail', params: {articleId: article.art_id}}"> -->
      <!-- 自定义标题 -->
      <div slot="title">{{ article.title }}</div>
      <!-- 自定义标题下面的内容 -->
      <div slot="label">
        <!-- 三张封面图片 -->
        <div class="imgs_cover" v-if="article.cover.type === 3">
          <van-image
            v-for="(item, index) in article.cover.images"
            :key="index"
            fit="contain"
            :src="item"
          />
        </div>
        <div class="baseInfo">
          <span>{{ article.aut_name }}</span>
          <span>{{ article.comm_count }}评论</span>
          <span>{{ article.pubdate | dateFormat}}</span>
        </div>
      </div>
      <!-- 自定义右侧内容(1张封面) -->
      <van-image
        class="img_cover"
        v-if="article.cover.type === 1"
        fit="contain"
        :src="article.cover.images[0]"
      />
    </van-cell>
  </van-cell-group>
</template>

<script>
export default {
  name: 'articleItem',
  data () {
    return {

    }
  },

  props: {
    article: {
      type: Object,
      required: true
    }
  },

  created () {

  },

  methods: {

  }
}
</script>

<style scoped lang='less'>
.article_item {
  // 右侧
  .van-cell__value {
    flex: unset;
    margin-left: 10px;
  }
  // 1张封面
  .img_cover {
    width: 232px;
    height: 146px;
  }
  .baseInfo {
    span {
      margin-right: 8px;
    }
  }

  .imgs_cover {
    display: flex;
    justify-content: space-between;
    margin: 15px 0;
    padding-right: 15px;
    width: 100%;
    .van-image {
      width: 232px;
      height: 146px;
    }
    .van-image:nth-child(2) {
      margin: 0 3px;
    }
  }
}
</style>
