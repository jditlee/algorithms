module.exports = {
  plugins: {
    // 属于postcss其中的一个插件，自动给样式添加前缀，我们脚手架默认已经集成
    // autoprefixer: {
    //   browsers: ['Android >= 4.0', 'iOS >= 8'],
    // },
    'postcss-pxtorem': {
      // rootValue 设计稿十分之一的值 vant: 375
      // 如果是vant: 37.5
      // 如果不是vant： 75
      rootValue ({ file }) {
        return file.indexOf('vant') !== -1 ? 37.5 : 75
      },
      propList: ['*'],
      exclude: 'github-markdown'
    },
  },
}