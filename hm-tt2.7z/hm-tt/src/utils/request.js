import axios from 'axios'
import { getItem } from '@/utils/storage.js'
import store from '@/store'
import JSONBig from 'json-bigint'
// JSONBig.parse === JSON.parse 能处理大数
// JSONBig.stringify === JSON.stringify
// const json = '{"artid": 1302062843876605952}'

// console.log(JSON.parse(json))
// console.log(JSONBig.parse(json).artid.toString())

// console.log(JSON.stringify(JSONBig.parse(json)))
// console.log(JSONBig.stringify(JSONBig.parse(json)))

// 通过axios.create可以进行所有的统一配置，会返回一个新的axios实例对象
const request = axios.create({
  baseURL: 'http://ttapi.research.itcast.cn/',
  transformResponse: [function (data) {
    // 对 data 进行任意转换处理
    try {
      return JSONBig.parse(data)
    } catch (err) {
      return data
    }
  }]
})

// 请求拦截器
request.interceptors.request.use((config) => {
  if (store.state.user) {
    config.headers.Authorization = 'Bearer ' + getItem('HMTT_TOKEN').token
  }
  return config
})

// 后续发送请求 通过request发送请求
export default request

// a.vue
// impot request from './request.js'
