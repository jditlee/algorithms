<template>
  <van-icon
    :color="value ? '#ffa500': '#777'"
    :name="value ? 'star' : 'star-o'"
    @click="clickCollect"
  />
</template>

<script>
import { addCollect, deleteCollect } from '@/api/article.js'
export default {
  data () {
    return {

    }
  },

  props: {
    value: {
      type: Boolean,
      required: true
    },
    artId: {
      type: [Number, String, Object],
      retuired: true
    }
  },

  created () {

  },

  methods: {
    async clickCollect () {
      try {
        if (this.value) {
          // 已经收藏，取消收藏
          await deleteCollect(this.artId)
          this.$toast.success('取消收藏')
        } else {
          // 为收藏，点击收藏
          await addCollect(this.artId)
          this.$toast.success('收藏成功')
        }
      } catch (err) {
        this.$toast.fail('收藏失败')
      }
      this.$emit('input', !this.value)
    }
  }
}
</script>

<style scoped lang='less'>

</style>
