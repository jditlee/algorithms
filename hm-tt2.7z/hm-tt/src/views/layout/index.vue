<template>
  <div class="layout">
    <!-- 子路由 -->
    <router-view></router-view>
    <!-- tabbr route: 开启路由 -->
    <van-tabbar route class="bottom-vant-tabbar">
      <!-- 首页 -->
      <van-tabbar-item to="/">
        <i slot="icon" class="heimatoutiao hmtt-shouye"></i>
        <span>首页</span>
      </van-tabbar-item>
      <!-- 问答 -->
      <van-tabbar-item to="/qa">
        <i slot="icon" class="heimatoutiao hmtt-wenda"></i>
        <span>问答</span>
      </van-tabbar-item>
      <!-- 视频 -->
      <van-tabbar-item to="/video">
        <i slot="icon" class="heimatoutiao hmtt-shipin"></i>
        <span>视频</span>
      </van-tabbar-item>
      <!-- 我的 -->
      <van-tabbar-item to="/profile">
        <i slot="icon" class="heimatoutiao hmtt-wode"></i>
        <span>我的</span>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  name: 'layout',
  data () {
    return {
    }
  },

  created () {

  },

  methods: {

  }
}
</script>

<style scoped lang='less'>
.layout {
  .bottom-vant-tabbar {
    .heimatoutiao {
      font-size: 40px;
    }

    span {
      font-size: 20px;
    }
  }
}
</style>
