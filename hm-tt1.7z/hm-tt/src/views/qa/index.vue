<template>
  <div>
    问答
  </div>
</template>

<script>
export default {
  name: '/qa',
  data () {
    return {

    }
  },

  created () {},

  methods: {

  }
}
</script>

<style scoped lang='less'>

</style>
