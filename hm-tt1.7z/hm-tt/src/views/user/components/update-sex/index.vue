<template>
  <van-picker
    title="性别"
    show-toolbar
    :columns="columns"
    @confirm="onConfirm"
    @cancel="onCancel"
    :default-index="value"
  />
</template>

<script>
import { updateProfile } from '@/api/user.js'
export default {
  data () {
    return {
      columns: ['男', '女']
    }
  },

  props: {
    value: {
      type: Number,
      required: true
    }
  },

  created () {

  },

  methods: {
    async onConfirm (value, index) {
      if (this.value === index) return this.$emit('close')
      // 发送请求
      try {
        await updateProfile({
          gender: index
        })
        this.$toast('更新成功')
        this.$emit('close')
        this.$emit('input', index)
      } catch (err) {
        return this.$toast('更改失败')
      }
    },
    onCancel () {
      this.$emit('close')
    }
  }
}
</script>

<style scoped lang='less'>

</style>
