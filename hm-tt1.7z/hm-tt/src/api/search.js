/**
 * 搜索模块请求
 */

import request from '../utils/request.js'

/**
 * 获取搜索联想建议
 * @param {*} q 根据哪个字段获取联想建议
 */
export const getSearchSuggestion = q => {
  return request({
    url: '/app/v1_0/suggestion',
    method: 'GET',
    params: {
      q
    }
  })
}

/**
 * 获取搜索结果
 * @param {q, page, per_page} params 获取搜索结果参数
 */
export const getSearchResults = params => {
  return request({
    url: '/app/v1_0/search',
    method: 'GET',
    params
  })
}
