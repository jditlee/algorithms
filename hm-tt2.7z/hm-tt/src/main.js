import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// vant
import Vant from 'vant'
import 'vant/lib/index.css'
// amfe-flexible：rem的基准值：根据不同的屏幕设置html根节点的字体大小
import 'amfe-flexible'

// 全局样式
import './styles/index.less'

// 引入自己配置的dayjs
import '@/utils/dayjs.js'

Vue.use(Vant)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
