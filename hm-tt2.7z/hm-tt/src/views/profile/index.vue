<template>
  <div class="profile">
    <!-- 未登录 -->
    <div v-if="!user" class="not_login header">
      <div class="login_box" @click="$router.push('/login')">
        <img src="~@/assets/mobile.png" alt="">
        <span>登录 / 注册</span>
      </div>
    </div>

    <!-- 已登录 头部 -->
    <div v-else class="header login-container">
      <!-- 基本信息 -->
      <div class="base">
        <!-- 左侧信息 -->
        <div class="left">
          <van-image
            class="avatar"
            round
            fit="cover"
            :src="userInfo.photo"
          />
          <span class="name">{{ userInfo.name }}</span>
        </div>
        <!-- 右侧编辑按钮 -->
        <van-button to="/user" round size="mini" type="default">编辑资料</van-button>
      </div>
      <!-- 显示个人数据 -->
      <div class="data">
        <div class="data-item">
          <span>{{ userInfo.art_count }}</span>
          <span>头条</span>
        </div>
        <div class="data-item">
          <span>{{ userInfo.follow_count }}</span>
          <span>关注</span>
        </div>
        <div class="data-item">
          <span>{{ userInfo.fans_count }}</span>
          <span>粉丝</span>
        </div>
        <div class="data-item">
          <span>{{ userInfo.like_count }}</span>
          <span>获赞</span>
        </div>
      </div>
    </div>

    <!-- 宫格导航 -->
    <van-grid class="nav-grid" :column-num="2">
      <van-grid-item>
        <i slot="icon" class="heimatoutiao hmtt-shoucang"></i>
        <span class="text" slot="text">收藏</span>
      </van-grid-item>
      <van-grid-item>
        <i slot="icon" class="heimatoutiao hmtt-lishi"></i>
        <span class="text" slot="text">历史</span>
      </van-grid-item>
    </van-grid>

    <!-- 通知\小智\退出 -->
    <div class="bottom_box">
      <van-cell title="消息通知" is-link />
      <van-cell title="小智同学" is-link />
    </div>
    <van-cell v-if="user" class="logout_btn" @click="logout" title="退出登录" />
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { getUserInfo } from '@/api/user.js'
export default {
  name: 'profile',
  data () {
    return {
      userInfo: {}
    }
  },

  computed: {
    ...mapState(['user'])
  },

  created () {
    if (this.user) {
      // 发送请求
      this.loadUserInfo()
    }
  },

  methods: {
    // 点击退出
    logout () {
      // 弹出确认框
      this.$dialog.confirm({
        title: '黑马头条',
        message: '确认退出?'
      })
        .then(() => {
          // 点击了确认
          console.log('点击了确认')
          this.$store.commit('changeUser', null)
        })
        .catch(() => {
          // 点击了取消
          this.$toast('取消退出')
        })
    },
    // 加载用户数据
    async loadUserInfo () {
      try {
        const { data: res } = await getUserInfo()
        this.userInfo = res.data
      } catch (err) {
        console.dir(err)
        this.$toast.fail('获取数据失败')
      }
    }
  }
}
</script>

<style scoped lang='less'>
.profile {
  // 公用头部
  .header {
    width: 750px;
    height: 401px;
    background: url(~@/assets/banner.png);
    background-size: cover;
  }
  // 未登录
  .not_login {
    display: flex;
    justify-content: center;
    align-items: center;
    .login_box {
      display: flex;
      flex-direction: column;
      align-items: center;
      img {
        width: 132px;
        height: 132px;
        margin-bottom: 10px;
      }
      span {
        color: #fff;
        font-size: 28px;
      }
    }
  }
  // 已登录
  .login-container {
    // 个人基本信息
    .base {
      height: 240px;
      width: 750px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 70px 20px 0 20px;
      box-sizing: border-box;
      .left {
        display: flex;
        align-items: center;
        .avatar {
          width: 132px;
          height: 132px;
          margin-right: 22px;
        }
        .name {
          font-size: 30px;
          color: #FFFFFF;
        }
      }
    }

    // 数据
    .data {
      height: 161px;
      width: 750px;
      display: flex;
      .data-item {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: #fff;
        span:nth-child(1) {
          font-size: 36px;
          margin-bottom: 18px;
        }
        span:nth-child(2) {
          font-size: 23px;
        }
      }
    }
  }
  // 宫格导航
  .nav-grid {
    .heimatoutiao {
      font-size: 45px;
    }

    .hmtt-shoucang {
      color: #EB5253;
    }

    .hmtt-lishi {
      color: #FF9D1D;
    }

    .text {
      margin-top: 10px;
      font-size: 28px;
      color: #000;
    }
  }

  .bottom_box {
    margin: 10px 0;
  }

  .logout_btn {
    text-align: center;
    color: #D86262;
    height: 100px;
  }
}
</style>
