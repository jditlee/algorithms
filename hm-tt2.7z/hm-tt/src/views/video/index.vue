<template>
  <div>
    视频
  </div>
</template>

<script>
export default {
  name: 'shipin',
  data () {
    return {

    }
  },

  created () {

  },

  methods: {

  }
}
</script>

<style scoped lang='less'>

</style>
