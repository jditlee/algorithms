<template>
  <div class="suggestion">
    <van-cell
    v-for="(item, index) in suggestion"
    :key="index"
    icon="search">
      <div @click="$emit('search', item)" slot="title" v-html="highlight(item)"></div>
    </van-cell>
  </div>
</template>

<script>
import { getSearchSuggestion } from '@/api/search.js'
import { debounce } from 'lodash'
export default {
  data () {
    return {
      suggestion: [],
      setTimeId: 0,
      str: '<span style="color: red">hello</span> world'
    }
  },

  props: {
    searchText: {
      type: String,
      required: true
    }
  },

  watch: {
    searchText: {
      // handler: 坚挺的数据发生变化，就会触发该钩子函数
      // handler () {
      //   clearTimeout(this.setTimeId)
      //   this.setTimeId = setTimeout(() => {
      //     this.loadSuggestion()
      //   }, 700)
      // },
      handler: debounce(function () {
        this.loadSuggestion()
      }, 700),
      immediate: true
    }
  },

  created () {

  },

  methods: {
    // 加载联想建议
    async loadSuggestion () {
      try {
        const { data: res } = await getSearchSuggestion(this.searchText)
        this.suggestion = res.data.options
      } catch (err) {
        this.$toast.fail('获取数据失败')
      }
    },
    // 处理搜索建议每一项的高亮
    highlight (text) {
      // text: 要处理的每一项的文本
      // 替换的内容
      const replaceStr = '<span style="color: red">' + this.searchText + '</span>'
      // 动态生成正则表达式
      const reg = new RegExp(this.searchText, 'gi')
      // 实现替换
      const newText = text.replace(reg, replaceStr)
      return newText
    }
  }
}
</script>

<style scoped lang='less'>

</style>
